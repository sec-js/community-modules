from .process_injection_method1 import *
